package crack_the_coding_interview;

 
import java.util.LinkedList;
 
public class HashTable {
 
    public static class HTObject {
        public String key;
        public Integer value;
    }
 
    public static final int ARR_SIZE = 128;
    //Instead of having a linkedList of LinkedLists, we could with lesser space have
    //an array of Linkedlists. by rather declaring an array like this: LinkedList [] myArray=new LinkedList[ARR_SIZE];
    private LinkedList<HTObject>[] arr = new LinkedList[ARR_SIZE];
 
    public HashTable() {
        //init vals in array
        for(int i=0; i<ARR_SIZE; i++) {
            arr[i] = null;
        }
    }
 
    private HTObject getObj(String key) {
        if(key == null)
            return null;
 
        int index = key.hashCode() % ARR_SIZE;
        LinkedList<HTObject> items = arr[index];
 
        if(items == null)
            return null;
 
        for(HTObject item : items) {
            if(item.key.equals(key))
                return item;
        }
 
        return null;
    }
 
    public Integer get(String key) {
        HTObject item = getObj(key);
 
        if(item == null)
            return null;
        else
            return
            item.value;
    }
 
    public void put(String key, Integer value) {
        int index = key.hashCode() % ARR_SIZE;
        LinkedList<HTObject> items = arr[index];
 
        if(items == null) {
            items = new LinkedList<HTObject>();
 
            HTObject item = new HTObject();
            item.key = key;
            item.value = value;
 
            items.add(item);
 
            arr[index] = items;
        }
        else {
            for(HTObject item : items) {
                if(item.key.equals(key)) {
                    item.value = value;
                    return;
                }
            }
 
            HTObject item = new HTObject();
            item.key = key;
            item.value = value;
 
            items.add(item);
        }
    }
 
    public void delete(String key) {
        int index = key.hashCode() % ARR_SIZE;
        LinkedList<HTObject> items = arr[index];
 
        if(items == null)
            return;
 
        for(HTObject item : items) {
            if (item.key.equals(key)) {
                items.remove(item);
                return;
            }
        }
    }
 public static void main(String args[]){
     HashTable a =new HashTable();
     a.put("Angela", 1);
     a.put("Angel", 2);
     a.put("Ange", 3);
     System.out.println(a.getObj("Ange"));
 }
}