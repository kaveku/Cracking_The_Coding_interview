/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crack_the_coding_interview;

public class CheckIfPalindrome {
    public void checkPal(String a){
    StringBuffer k=new StringBuffer(a).reverse();
    
    if(k.toString().equals(a)){System.out.println("yes");}
   
    }
    public static void main(String [] args){
    CheckIfPalindrome h=new CheckIfPalindrome();
    h.checkPal("omo");
    }
    
}
