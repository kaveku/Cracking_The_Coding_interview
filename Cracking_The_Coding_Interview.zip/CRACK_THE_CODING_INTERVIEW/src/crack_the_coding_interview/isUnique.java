/*: Implement an algorithm to determine 
if a string has all unique characters. 
What if you cannot use additional data structures?*/

package crack_the_coding_interview;
public class isUnique {
        public boolean myUnique(String myString){
            myString=myString.toLowerCase();
            if(myString.length()>128){
                return false;
            }
            boolean [] charSet=new boolean[128];
            for(int i=0;i<myString.length();i++){
            int myVal= myString.charAt(i);
            if(charSet[myVal]){
                return false;
            }
            charSet[myVal]=true;
        }
            return true;
        }
        public static void main(String[] args){
            isUnique first=new isUnique();
            System.out.println(first.myUnique("Angela"));
        }
}
