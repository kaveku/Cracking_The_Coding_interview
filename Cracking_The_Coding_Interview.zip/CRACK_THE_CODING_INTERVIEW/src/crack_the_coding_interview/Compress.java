/*
String Compression: Implement a method to perform basic string compression using 
the counts of repeated characters. For example, the string aabcccccaaa 
would become a2blc5a3. If the "compressed "string would not become 
smaller than the original string, your method should return 
the original string. You can assume the string has only uppercase and 
lowercase letters (a - z)
 */
package crack_the_coding_interview;

import java.util.ArrayList;

public class Compress {
    int keepStringTrack=0;
    public String compress(String a){
        StringBuilder my=new StringBuilder();
        ArrayList myArr=new ArrayList();
        char [] myChar=a.toCharArray();
        int count=1;
        for(int i=0;i<myChar.length-1;i++){
        if(myChar[i]==myChar[i+1]){
            count=count+1;
            if((i+1)==myChar.length-1){
                my.append(myChar[i]);
                my.append(count);
                myArr.add(myChar[i]);
                myArr.add(count);
            }
        }

        else{
            System.out.println("no");
            my.append(myChar[i]);
            my.append(count);
            myArr.add(myChar[i]);
            myArr.add(count);
            count=1;
        }
        }
         if(myChar[myChar.length-1]!=myChar[myChar.length-2]){
            my.append(myChar[myChar.length-1]);
            my.append(count);
            myArr.add(myChar[myChar.length-1]);
            myArr.add(count);
         }
         String mine=my.toString();
         if(mine.length()>=a.length()){return a;}
         else{return mine;}
       
    }
    
    public static void main(String [] args){
    Compress mine=new Compress();
    System.out.println(mine.compress("aKKKwwwwwwwwwwwwwwwwwwwwww"));
    }
}
