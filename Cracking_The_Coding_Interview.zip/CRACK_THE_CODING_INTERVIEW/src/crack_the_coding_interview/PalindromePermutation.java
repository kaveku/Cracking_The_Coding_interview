/*Given a string, write a function to check if 
it is a permutation of a palindrome. A palindrome is a word 
or phrase that is the same forwards and backwards, A permutation 
is a rearrangement of letters. The palindrome does not need 
to be limited to just dictionary words. 
EXAMPLE Input: Tact Coa Output: True (permutations: "taco cat""atco eta" etc.) */

//N.B Check, does it have non letter characters? ask. If so, remove them first! before implementing the algorithm.
package crack_the_coding_interview;

import java.util.HashMap;

public class PalindromePermutation {
    public boolean checkPalindromePermutation(String myString){
       HashMap<Character,Integer>map=new HashMap<>();
       System.out.print(map);
       System.out.print(map.get('k'));
       char[]myChars=myString.toCharArray();
       for(int i=0;i<myChars.length;i++){
       if(map.get(myChars[i])!=null){map.put(myChars[i],map.get(myChars[i])+1);}
       else{map.put(myChars[i],1);}
       }
       System.out.print(map);
       if(myChars.length%2==0){return false;}
       boolean check=false;
      for (Character c : map.keySet())  
      {
          //System.out.println("key: " + map.get(c));
          if(map.get(c)==1){check=true;}
          if(map.get(c)>2 & map.get(c)%2!=0 & check ){
              System.out.println("not check");
              return false;}
      }
          return true;
    }

    public static void main(String [] args){
        PalindromePermutation a=new PalindromePermutation();
        System.out.println(a.checkPalindromePermutation("Tact Coa "));
    }
}
