package crack_the_coding_interview;

// Java program to print all permutations of a 
// given string. 
public class GeneratingPermutations
{ 

	private void permute(String str, int left, int right) 
	{ 
		if (left == right) 
			System.out.println(str); 
		else
		{ 
			for (int i = left; i <= right; i++) 
			{ 
				str = swap(str,left,i); 
				permute(str, left+1, right); 
				str = swap(str,left,i); 
			} 
		} 
	} 

	public String swap(String a, int i, int j) 
	{ 
		char temp; 
		char[] charArray = a.toCharArray(); 
		temp = charArray[i] ; 
		charArray[i] = charArray[j]; 
		charArray[j] = temp; 
		return String.valueOf(charArray); 
	} 
	public static void main(String[] args) 
	{ 
		String str = "cate"; 
		int n = str.length(); 
		GeneratingPermutations permutation = new GeneratingPermutations(); 
		permutation.permute(str, 0, n-1); 
	} 

} 

// This code is contributed by Mihir Joshi 
