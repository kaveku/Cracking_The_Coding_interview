/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crack_the_coding_interview;

import java.util.Arrays;

/**
 *
 * @author user
 */
public class URLify {
    public void urlify(String myString){
        int myNewLength=myString.length();
        for(int i=0;i<myString.length();i++){
            if(myString.charAt(i)==' '){myNewLength=myNewLength+2;}
        }
        char [] myNewChars=new char[myNewLength];
        char[]myCharArray=myString.toCharArray();
        int jump=0;
        for(int i=0;i<myString.length();i++){
            myNewChars[i+jump]=myCharArray[i];
            if(myCharArray[i]==' ')
            {
                myNewChars[i+jump]='%';
                myNewChars[i+1+jump]='2';
                myNewChars[i+2+jump]='0';
                jump=jump+2;
                //System.out.println("yes");
            }
        }
        String myNewString=String.valueOf(myNewChars);
        System.out.println(myNewString);
    }
    public static void main(String [] args){
        URLify a=new URLify();
        a.urlify("and  me ");
    }
    
}
