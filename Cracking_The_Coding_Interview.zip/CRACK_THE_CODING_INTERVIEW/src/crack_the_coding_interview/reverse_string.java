/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crack_the_coding_interview;

/**
 *
 * @author user
 */
public class reverse_string {
//Reversing an array in Java.
    public void reverse(String n){
        char [] array1=n.toCharArray();
        int right=array1.length-1;
        for(int left=0;left<right;left++,right--){
        char temp=array1[left];
        array1[left]=array1[right];
        array1[right]=temp;
    }
        for(char i:array1){
            System.out.print(i);
        }
    
        }
    
    public static void main(String[] args) {
reverse_string a=new reverse_string();
String totest="yes we can do this";
a.reverse(totest);
    }
    
}
