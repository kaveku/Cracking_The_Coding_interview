
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

 /*There are three types of edits that can be
 performed on strings: insert a character, remove a 
 character, or replace a character. Given two strings, write 
 a function to check if they are one edit (or zero edits) away.
package crack_the_coding_interview;*/

//N.B. NOT YET SOLVED!!!!!!


public class CheckEdits {
    public boolean check(String a,String b){
        StringBuilder mine=new StringBuilder(a);
        mine.append(b);
        String myString=mine.toString();
        char []myChar=myString.toCharArray();
        //System.out.println(myChar);
        HashMap <Character,Integer> myHash=new HashMap<>();
        for(int i=0;i<myChar.length;i++){
            if(myHash.get(myChar[i])!=null){
                myHash.put(myChar[i],myHash.get(myChar[i])+1);
            }
            else{myHash.put(myChar[i],1);}
        }
        for(int i=0;i<myHash.size();i++){
            if(myHash.get(myChar[i])>1&myHash.get(myChar[i])%2==0){return false;}
        }
        System.out.println(myHash);
        return true;
    }
    public static void main (String [] args){
        CheckEdits myEdits=new CheckEdits();
       System.out.println(myEdits.check("pppp", "pppp"));
    }
}
