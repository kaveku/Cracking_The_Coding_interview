/*
  implement an algorithm to find the kth to last element of a singly linked list.
 */
package crack_the_coding_interview;

import java.util.LinkedList;

public class ReturnKthtoLastSinglyLinkedList {
    class Node{
    int data;
    Node next;
    public Node(int value){
    data=value;
    }
    }
    Node head=null;
    Node tail=null;
    public void put(int myData){
    Node newest=new Node(myData);
    if(head==null){
    head=new Node(myData);
    tail=head;
    }
    else{
        tail.next=newest;
        tail=newest;   
    }
    }
    public void printValues(){
    Node current=head;
    System.out.println(current.data);
    while(current.next!=null){
        current=current.next;
        System.out.println(current.data);
    }
    }
    
    public int getKthLastElement(int k) {

int counter1=1;
int counter2=1;
Node current=head;
while (counter1<k){
    System.out.println("yes");
    counter1=counter1+1;
    current=current.next;         
}
        while(current.next!=null){
            System.out.println("no");
            counter1=counter1+1;
            counter2=counter2+1;
            current=current.next;  
        }
     return counter2;   
}
    public boolean deleteMiddleNode( int deleted){
    if (head==null){return false;}
    Node current=head;
    if(current.data==deleted){head=current.next;return true;}
    while(current.next!=null){
        if(current.next.data==deleted){
            System.out.println(current.next.data);
        current.next=current.next.next;return true;
    }
        current=current.next;
    
    }
    return false;
    }
    
    public static void main(String [] args){
    ReturnKthtoLastSinglyLinkedList mine=new ReturnKthtoLastSinglyLinkedList();
    mine.put(1);
    mine.put(2);
    mine.put(3);
    mine.put(4);
    mine.put(5);
    mine.deleteMiddleNode(4);
    mine.printValues();
    //System.out.println(mine.getKthLastElement(5));
    }
}
