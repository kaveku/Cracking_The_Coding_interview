package crack_the_coding_interview;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayListExample
{
    public static void main(String[] args)
    {
        ArrayList<String> namesList = new ArrayList<String>(Arrays.asList( "alex", "brian", "charles", "alex") );
         
        System.out.println(namesList);
         
        namesList.remove(3);
         
        System.out.println(namesList);
    }
}