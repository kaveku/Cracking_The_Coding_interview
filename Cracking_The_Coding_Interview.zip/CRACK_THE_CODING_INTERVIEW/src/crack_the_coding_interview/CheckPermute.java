/*Check Permutation: Given two strings, 
write a method to decide if one is a 
permutation of the other*/
//Two string being permutations of each other means they have the same characters.
//even though in different order, and of course, they are of the same length!

package crack_the_coding_interview;

import java.util.Arrays;

public class CheckPermute {
    public boolean checkPermutation(String a, String b){
    if (a.length()!=b.length()){return false;}
    a=a.toLowerCase();
    b=b.toLowerCase();
    char [] myA=a.toCharArray();
    char[] myB=b.toCharArray();
    Arrays.sort(myA);
    Arrays.sort(myB);
    for(int i=0;i<a.length();i++){
        if(myA[i]!=myB[i]){return false;}
    }
    return true;
    }
    public static void main (String[] args){
    CheckPermute a=new CheckPermute();
    System.out.println(a.checkPermutation("wett", "ttew"));
    }
}
